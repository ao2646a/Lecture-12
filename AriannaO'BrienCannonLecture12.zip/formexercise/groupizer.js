(function () {
    "use strict";

    window.addEventListener("load", init);

  // Note: This function is called as soon as the window is loaded (and the browser
  // has created the HTML DOM for the page)
    function init() {
    // 1. Add event listener for clicking the #add-btn
        document.getElementById("add-btn").addEventListener("click", function () { 
            
            let c = document.getElementById("group-name").value;
            
            let inputs = document.querySelectorAll("ul input");    
            let empty = 0;
            let members = "";
            for (let i = 0; i < inputs.length; i++) {        
                if (inputs[i].value == ""){          
                    inputs[i].classList.add("invalid-input");          
                    inputs[i].innerText = 'please input member';          
                    empty = empty+1
                }
                else {
                    members = members+inputs[i].value+" , ";      
                }
            }
            if (empty == 0){
                document.write("The group " + c + " includes: " + members);
            }
        })
      
    // 2. Add event listener for changing the #member-size dropdown
        document.getElementById("group-size").addEventListener("change", function () { 
            let select = document.getElementById("group-size");
            let members = document.getElementById("member-list");
            if (select.value == "2"){
                let last = members.children[2];
                members.removeChild(last);
            }
        
            if (select.value == "4"){
                let li = document.createElement("li");
                let input = document.createElement("input");
                input.setAttribute("size", "40");
                input.setAttribute("type", "text");
                li.innerHTML = "Member 4:";
                li.appendChild(input);
                members.appendChild(li);
            }
        })
  // Add the rest of the functions here!
//    document.getElementById("add-btn").addEventListener("click", function() {    
//        let inputs = document.querySelectorAll("ul input");    
//        let empty = 0;    
//        for (let i = 0; i < inputs.length; i++) {        
//            if (inputs[i].value == ""){          
//                inputs[i].classList.add("invalid-input");          
//                inputs[i].innerText = 'please input member';          
//                empty = empty+1;        
//            }
//        }
    }
})();
